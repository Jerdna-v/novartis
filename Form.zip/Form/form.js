$(document).ready(function() {
  $("#phone-number").intlTelInput({
    preferredCountries: ['us', 'gb', 'jp', 'cn'],
    defaultCountry: 'us'
  });
});

$(document).ready(function() {
  var countryList = window.intlTelInputGlobals.getCountryData();
  for (var i = 0; i < countryList.length; i++) {
    var country = countryList[i];
    $('#country-selector').append('<option>' + country.name + '</option>');
  }
});

$(document).ready(function() {
  $('#languages').multiselect({
    nonSelectedText: 'Select languages',
    allSelectedText: 'All languages selected',
    nSelectedText: 'languages selected',
    includeSelectAllOption: true,
    selectAllText: 'Select all languages',
    enableFiltering: true,
    filterPlaceholder: 'Search',
    maxHeight: 300,
    buttonWidth: '100%',
    enableCaseInsensitiveFiltering: true,
    enableClickableOptGroups: true,
    enableCollapsibleOptGroups: true,
    enableHTML: true,
    dropRight: true,
    onChange: function(option, checked) {
      // Handle language selection here
    }
  });
});